<html>

<head>
    <title>WebCaixa v1.20.9_beta</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">
        body {
            margin-top: 5%;
            margin-left: 3%;
            margin-right: 3%;
            border: 3px solid gray;
            padding: 10px 10px 10px 10px;
            font-family: sans-serif;
        }

        .campos {
            background-color: #C0C0C0;
            font: 16px sans-serif;
            color: #000000;
        }

        .ui-autocomplete {
            max-height: 200px;
            overflow-y: auto;
            overflow-x: hidden;
            background-color: #fff;
            color: #000;
            border: 1px solid #ccc;
        }

        .ui-menu-item {
            padding: 5px;
        }

        .ui-menu-item:hover {
            background-color: #f0f0f0;
            cursor: pointer;
        }
    </style>

   <!-- Adicionando jQuery UI para o autocomplete -->
   <link rel="stylesheet" href="./css/themes.css">
   <script src="./js/jquery.js"></script>
   <script src="./js/ui.js"></script>   

    <?php
    include "../cabecprs.php";
    ?>

    <script>
        function FormataValor(Formulario, Campo, TeclaPres) {
            var tecla = TeclaPres.keyCode;
            var strCampo;
            var vr;
            var tam;
            var TamanhoMaximo = 10;

            eval("strCampo = document." + Formulario + "." + Campo);

            vr = strCampo.value;
            vr = vr.replace("/", "");
            vr = vr.replace("/", "");
            vr = vr.replace("/", "");
            vr = vr.replace(",", "");
            vr = vr.replace(".", "");
            vr = vr.replace(".", "");
            vr = vr.replace(".", "");
            vr = vr.replace(".", "");
            vr = vr.replace(".", "");
            vr = vr.replace(".", "");
            vr = vr.replace(".", "");
            vr = vr.replace("-", "");
            vr = vr.replace("-", "");
            vr = vr.replace("-", "");
            vr = vr.replace("-", "");
            vr = vr.replace("-", "");
            tam = vr.length;

            if (tam < TamanhoMaximo && tecla != 8) {
                tam = vr.length + 1;
            }

            if (tecla == 8) {
                tam = tam - 1;
            }

            if (tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105) {
                if (tam <= 3) {
                    strCampo.value = vr;
                }
                if ((tam > 3) && (tam <= 10)) {
                    strCampo.value = vr.substr(0, tam - 3) + '.' + vr.substr(tam - 3, tam);
                }
            }
        }

        function putFocus(formInst, elementInst) {
            if (document.forms.length > 0) {
                document.forms[formInst].elements[elementInst].focus();
            }
        }

        function validate(field) {
            var valid = ".0123456789"
            var ok = "yes";
            var temp;
            for (var i = 0; i < field.value.length; i++) {
                temp = "" + field.value.substring(i, i + 1);
                if (valid.indexOf(temp) == "-1") ok = "no";
            }
            if (ok == "no") {
                alert("Entrada Incorreta! \n  Digite apenas algarismos!");
                field.focus();
                field.select();
            }
        }
    </script>

    <script src="val_prod.js" charset="utf-8"></script>
    <script src="fch_aba.js"></script>

</head>

<body background="../images/bg1.jpg" text="#FFFFFF" onLoad="putFocus(0,0)">

    <?php
    $Sis     = "S7";
    $Rot     = "S7R2.1";
    $lg_user = $_REQUEST['c_s'];
    $user = substr($lg_user, 0, 8);
    $pss  = substr($lg_user, 8, 40);
    $DataHj = date('Y-m-d');

    $Mat_Vend  = trim($_POST['mat_vend']);
    $Vendedora = trim($_POST['vendedora']);
    $Cliente   = trim($_POST['cliente']);
    $DataNasc  = trim($_POST['data_nasc']);
    $Regula    = trim($_POST['ref_taxprod']);

    include "config.php";

    $idade = 0;
    if (!empty($DataNasc) && strpos($DataNasc, '/') !== false) {
        $partes = explode('/', $DataNasc);

        if (count($partes) === 3) {
            $dia = (int)$partes[0];
            $mes = (int)$partes[1];
            $ano = (int)$partes[2];

            if ($ano > 0) {
                $idade = date('Y') - $ano;
                if (date('md') < sprintf('%02d%02d', $mes, $dia)) {
                    $idade--;
                }
            }
        }
    }

    include "conexao.php";
    include "dbselect.php";

    $NumDocInicial = intval($std . "00000");

    $sql = "select * from taxas where codigo = 'TXP' order by datalt desc";
    $rs  = mysqli_query($conec, $sql) or die("Erro de Banco de Dados #1");
    $ln  = mysqli_fetch_array($rs);

    $DataAlt = $ln['datalt'];
    $Codigo  = $ln['codigo'];
    $VrProd  = (float)$ln['vltx'];
    $VrProdOriginal = $VrProd;
    $VrProdF = number_format($VrProd, 2, ',', '.');

    // ==============================
    // REGRAS DE VALIDAÇÃO
    // ==============================
    $Gratuidade = false;
    $TipoClienteExibicao = '';
    $MostrarCamposNormais = true;

    // Compatibilidade:
    // senior ou gratuidade => regra de cliente sênior
    if ($Regula === 'senior' || $Regula === 'gratuidade') {
        if ($idade >= $Senior) {
            $Gratuidade = true;
            $TipoClienteExibicao = 'Cliente Sênior';
            $MostrarCamposNormais = false;
        }
    } elseif ($Regula === 'aghata') {
        if ($idade >= $Aghata) {
            $Gratuidade = true;
            $TipoClienteExibicao = 'Cliente Mulher Aghata';
            $MostrarCamposNormais = false;
        }
    } elseif ($Regula === 'rev_estrella') {
        $Gratuidade = true;
        $TipoClienteExibicao = 'Cliente Revelação Estrella';
        $MostrarCamposNormais = false;
    }

    if ($Gratuidade) {
        $VrProd = 0.00;
        $VrProdF = number_format($VrProd, 2, ',', '.');
    }

    $VrProdAnteriorConsulta = $Gratuidade ? $VrProdOriginal : $VrProd;

    $sqlA  = "select * from taxas where codigo = 'TXP' and vltx <> $VrProdAnteriorConsulta order by datalt desc";
    $rsA   = mysqli_query($conec, $sqlA) or die("Erro de Banco de Dados #2");
    $lnA   = mysqli_fetch_array($rsA);

    $DtAltA = isset($lnA['datalt']) ? $lnA['datalt'] : '';
    $CodA   = isset($lnA['codigo']) ? $lnA['codigo'] : '';
    $VrAnt  = isset($lnA['vltx']) ? $lnA['vltx'] : 0;
    $VrAntF = number_format((float)$VrAnt, 2, ',', '.');

    $sql = "SELECT numdoc, datarec FROM registro 
            WHERE numdoc >= $NumDocInicial
              AND subtipo IN ('TXP', 'TXPG', 'TXC', 'PROD', 'BOOK', 'CHV', 'PRODK')
            ORDER BY numdoc DESC";
    $rs  = mysqli_query($conec, $sql) or die('Erro #3!');
    $ln  = mysqli_fetch_array($rs);

    $NumDoc = isset($ln['numdoc']) ? $ln['numdoc'] : $NumDocInicial;
    $DataRec = isset($ln['datarec']) ? $ln['datarec'] : $DataHj;

    if ($DataHj >= $DataRec) {
        $NumDoc = $NumDoc + 1;
    } else {
        echo "Entre em contato com o administrador do sistema.";
    }

    include "us_sist.php";
    if ($ch == 'no') {
        include "us_cad.php";
    }
    ?>

    <table width='100%' border='0' cellpadding='0' cellspacing='0'>
        <tr>
            <td width='9%'>
                <a href="taxaprod.php?c_s=<?php echo $lg_user ?>"><img src="./images/voltar.gif"></a>
            </td>
            <td width='82%' align='center'>
                <font color="gold" size="6"><b>
                        <center><u><i>TAXA DE PRODUÇÃO</i></u></center>
                    </b></font>
                <font size="5" color="#FFFFFF"><b>
                        <center><u><i>Valor Atual - <font color="aqua">R$ <?php echo $VrProdF; ?></font></i></u></center>
                    </b></font><br>
            </td>
            <td width='9%'>
                <a href="taxaprod.php?c_s=<?php echo $lg_user; ?>"><img src="./images/voltar.gif"></a>
            </td>
        </tr>

        <tr>
            <td></td>
            <td>
                <?php if ($Gratuidade && !empty($TipoClienteExibicao)) { ?>
                    <center>
                        <font color='lime' size='7'>
                            <b><i><?php echo $TipoClienteExibicao; ?></i></b>
                        </font>
                    </center>
                <?php } ?>
            </td>
            <td></td>
        </tr>
    </table><br>

    <?php
    if ($ch == 'ok-enc' or $ch == 'ok-cai' or $ch == 'ok-adm' or $ch == 'ok') {
    ?>
        <form name="taxaProd" method="post" action="confprod.php" onsubmit="return checkdata();" autocomplete="off">
            <table width="80%" border="5" cellpadding="10" cellspacing="0" align="center">
                <tr>
                    <td width="40%" align="center">
                        <font color='#FFFFFF' size='5'><b><i>Colaboradora</i></b></font>
                    </td>
                    <td width="40%" align="center">
                        <font color='#FFFFFF' size='5'><b><i>Cliente</i></b></font>
                    </td>
                    <td width="20%" align="center">
                        <font color='#FFFFFF' size='5'><b><i>Data Nasc.</i></b></font>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <font color='gold' size='4'><b><i><?php echo $Vendedora; ?></i></b></font>
                        <input type="hidden" name="vendedora" value="<?php echo $Vendedora; ?>">
                        <input type="hidden" name="mat_vend" value="<?php echo $Mat_Vend; ?>">
                    </td>
                    <td align="center">
                        <font color='lime' size='4'><b><i><?php echo $Cliente; ?></i></b></font>
                        <input type="hidden" name="cliente" value="<?php echo $Cliente; ?>">
                    </td>
                    <td align="center">
                        <font color='gold' size='4'><b><i><?php echo $DataNasc; ?></i></b></font>
                        <input type="hidden" name="data_nasc" value="<?php echo $DataNasc; ?>">
                    </td>
                </tr>
            </table><br>

            <table width="80%" border="5" cellpadding="10" cellspacing="0" align="center">
                <input type="hidden" name="vlr_unico" value="<?php echo $VrProd; ?>">

                <tr>
                    <td align="center">
                        <font size='5'><b><i>Nº Recibo</i></b></font>
                    </td>

                    <?php if ($MostrarCamposNormais) { ?>
                        <td align="center">
                            <font color='gold' size='5'>
                                <b><i><blink>Amizade Premiada?</blink></i></b>
                            </font>
                        </td>
                    <?php } ?>

                    <td align="center">
                        <font size='5'><b><i>Forma de Pagamento</i></b></font>
                    </td>
                    <td align="center">
                        <font size='5'><b><i>Valor</i></b></font>
                    </td>
                </tr>

                <tr>
                    <td rowspan="4" align="center">
                        <font size='5'><b><i><?php echo $NumDoc; ?></i></b></font>
                        <input type='hidden' name='txtdoc' size='10' maxlength='8' class='campos' value="<?php echo $NumDoc; ?>">
                    </td>

                    <?php if ($MostrarCamposNormais) { ?>
                        <td rowspan="4" align="center">
                            <font color='lime' size='5'><b><i>Não </i></b></font>
                            <input type='radio' name='rdtaxa' value='N' checked>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <font size='5'><b><i>Sim </i></b></font>
                            <input type='radio' name='rdtaxa' value='S'>
                        </td>
                    <?php } else { ?>
                        <input type='hidden' name='rdtaxa' value='N'>
                    <?php } ?>

                    <input type="hidden" name="txtvrprod" value="<?php echo $VrProd; ?>">
                    <input type="hidden" name="txtvrprodf" value="<?php echo $VrProdF; ?>">
                    <input type="hidden" name="regula" value="<?php echo $Regula; ?>">
                    <input type="hidden" name="senior" value="<?php echo $Senior; ?>">
                    <input type="hidden" name="aghata" value="<?php echo $Aghata; ?>">
                    <input type="hidden" name="txtuser" value="<?php echo $lg_user; ?>">
                    <input type="hidden" name="mat_vend" value="<?php echo $Mat_Vend; ?>">

                    <td align="center">
                        <?php if ($Gratuidade) { ?>
                            <font color='lime' size='5'><b><i>GRATUIDADE</i></b></font>
                            <input type="hidden" name="lsPr1" value="99">
                            <input type="hidden" name="txt1" value="0.00">
                        <?php } else { ?>
                            <select name="lsPr1" class="campos" autofocus>
                                <?php
                                include "dbselect.php";
                                $sqlpr1 = "select * from formapag where (codpag <= 30 or codpag >= 70) and codpag <> 99 order by codpag";
                                $rspr1 = mysqli_query($conec, $sqlpr1) or die("Não foi possível acessar os Dados");

                                while ($lnpr1 = mysqli_fetch_array($rspr1)) {
                                    $CodPag1 = $lnpr1['codpag'];
                                    $ModPag1 = $lnpr1['modpag'];
                                    echo "<option value='$CodPag1' class='campos'>$ModPag1</option>";
                                }

                                mysqli_free_result($rspr1);
                                ?>
                            </select>
                        <?php } ?>
                    </td>

                    <td align="center">
                        <font size="5"><b><i>R$ </i></b></font>
                        <?php if ($Gratuidade) { ?>
                            <font size='5'><b><i>0,00</i></b></font>
                            <input type="hidden" name="txt1" value="0.00">
                        <?php } else { ?>
                            <input type="text" name="txt1" size="6" maxlength="6" class="campos" OnKeyUp="FormataValor('taxaProd', 'txt1', event); ">
                        <?php } ?>
                    </td>
                </tr>

                <?php if ($MostrarCamposNormais) { ?>
                    <tr>
                        <td align="center">
                            <select name="lsPr2" class="campos">
                                <?php
                                include "dbselect.php";
                                $sqlpr2 = "select * from formapag where (codpag <= 30 or codpag >= 70) and codpag <> 99 order by codpag";
                                $rspr2 = mysqli_query($conec, $sqlpr2) or die("Não foi possível acessar os Dados");

                                while ($lnpr2 = mysqli_fetch_array($rspr2)) {
                                    $CodPag2 = $lnpr2['codpag'];
                                    $ModPag2 = $lnpr2['modpag'];
                                ?>
                                    <option value="<?php echo $CodPag2; ?>" class="campos"><?php echo $ModPag2; ?></option>
                                <?php
                                }

                                mysqli_free_result($rspr2);
                                ?>
                            </select>
                        </td>
                        <td align="center">
                            <font size="5"><b><i>R$ </i></b></font>
                            <input type="text" name="txt2" size="6" maxlength="6" class="campos" OnKeyUp="FormataValor('taxaProd', 'txt2', event); ">
                        </td>
                    </tr>

                    <tr>
                        <td align="center">
                            <select name="lsPr3" class="campos">
                                <?php
                                include "dbselect.php";
                                $sqlpr3 = "select * from formapag where (codpag <= 30 or codpag >= 70) and codpag <> 99 order by codpag";
                                $rspr3 = mysqli_query($conec, $sqlpr3) or die("Não foi possível acessar os Dados");

                                while ($lnpr3 = mysqli_fetch_array($rspr3)) {
                                    $CodPag3 = $lnpr3['codpag'];
                                    $ModPag3 = $lnpr3['modpag'];
                                ?>
                                    <option value="<?php echo $CodPag3; ?>" class="campos"><?php echo $ModPag3; ?></option>
                                <?php
                                }

                                mysqli_free_result($rspr3);
                                ?>
                            </select>
                        </td>
                        <td align="center">
                            <font size="5"><b><i>R$ </i></b></font>
                            <input type="text" name="txt3" size="6" maxlength="6" class="campos" OnKeyUp="FormataValor('taxaProd', 'txt3', event); ">
                        </td>
                    </tr>
                <?php } else { ?>
                    <tr></tr>
                    <tr></tr>
                <?php } ?>
            </table><br>

            <table width="100%" border="0" cellspacing="0">
                <tr>
                    <td width="9%"></td>
                    <td width="82%" align="center">
                        <input type="hidden" name="txtuser" value="<?php echo $lg_user; ?>">
                        <input type='submit' name='btenviar' value='Continuar'>
                        &nbsp;&nbsp;
                        <?php if ($MostrarCamposNormais) { ?>
                            <input type='reset' name='btreset' value='Limpar'><br><br>
                        <?php } ?>
                    </td>
                    <td width="9%" align="right"></td>
                </tr>
            </table><br>
        </form>
    <?php
    } else {
    ?>
        <br><br>
        <font size='6'><b>
                <center>Acesso <font color='gold'><blink><u>não Autorizado</u></blink></font>
                    <font color='#FFFFFF'>!!!</font>
                </center>
            </b></font><br><br>
        <center><a href='servrec.php?c_s=<?php echo $lg_user; ?>'><img src='images/voltar.gif'></a></center><br>
    <?php
    }

    $SisRot = "S-7.2.1";
    include "rodape.php";
    mysqli_close($conec);
    ?>

</body>

</html>