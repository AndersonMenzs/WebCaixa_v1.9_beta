<html>

<head>
    <title>WebCaixa v1.20.9_beta</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">
    body {
        margin-top: 2%;
        margin-left: 5%;
        margin-right: 5%;
        border: 3px solid gray;
        padding: 10px 10px 10px 10px;
        font-family: sans-serif;
    }

    .campos {
        background-color: #C0C0C0;
        font: 16px sans-serif;
        color: #000000;
    }
    </style>

    <SCRIPT LANGUAGE="JavaScript">
    function putFocus(formInst, elementInst) {
        if (document.forms.length > 0) {
            document.forms[formInst].elements[elementInst].focus();
        }
    }
    </script>

    <Script>
    function validnome(field) {
        var valid = "ABCDEFGHIJKLMNOPQRSTUVWXYZ "
        var ok = "yes";
        var temp;
        for (var i = 0; i < field.value.length; i++) {
            temp = "" + field.value.substring(i, i + 1);
            if (valid.indexOf(temp) == "-1") ok = "no";
        }
        if (ok == "no") {
            alert("Entrada Incorreta! \n  Digite Apenas Letras!");
            field.value = "";
            field.focus();
            field.select();
        }
    }
    </script>

    <Script>
    function validate(field) {
        var valid = "0123456789"
        var ok = "yes";
        var temp;
        for (var i = 0; i < field.value.length; i++) {
            temp = "" + field.value.substring(i, i + 1);
            if (valid.indexOf(temp) == "-1") ok = "no";
        }
        if (ok == "no") {
            alert("Entrada Incorreta! \n  Digite apenas algarismos!");
            field.value = "";
            field.focus();
            field.select();
        }
    }
    </script>

    <Script>
    function validCPF(field) {
        var valid = ".-0123456789"
        var ok = "yes";
        var temp;
        for (var i = 0; i < field.value.length; i++) {
            temp = "" + field.value.substring(i, i + 1);
            if (valid.indexOf(temp) == "-1") ok = "no";
        }
        if (ok == "no") {
            alert("Entrada Incorreta! \n  Digite apenas algarismos!");
            field.value = "";
            field.focus();
            field.select();
        }
    }
    </script>

    <Script>
    function validata(field) {
        var valid = "/0123456789"
        var ok = "yes";
        var temp;
        for (var i = 0; i < field.value.length; i++) {
            temp = "" + field.value.substring(i, i + 1);
            if (valid.indexOf(temp) == "-1") ok = "no";
        }
        if (ok == "no") {
            alert("Entrada Incorreta! \n  Digite apenas algarismos!");
            field.value = "";
            field.focus();
            field.select();
        }
    }
    </script>

    <Script>
    function validcpf(field) {
        var valid = ".-0123456789"
        var ok = "yes";
        var temp;
        for (var i = 0; i < field.value.length; i++) {
            temp = "" + field.value.substring(i, i + 1);
            if (valid.indexOf(temp) == "-1") ok = "no";
        }
        if (ok == "no") {
            alert("Entrada Incorreta! \n  Digite apenas algarismos!");
            field.value = "";
            field.focus();
            field.select();
        }
    }
    </script>

    <script>
    function FormataData(Formulario, Campo, TeclaPres) {
        var tecla = TeclaPres.keyCode;
        var strCampo;
        var vr;
        var tam;
        var TamanhoMaximo = 10;

        eval("strCampo = document." + Formulario + "." + Campo);

        vr = strCampo.value;
        vr = vr.replace("/", "");
        vr = vr.replace("/", "");
        vr = vr.replace("/", "");
        vr = vr.replace(",", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        tam = vr.length;

        if (tam < TamanhoMaximo && tecla != 8) {
            tam = vr.length + 1;
        }

        if (tecla == 8) {
            tam = tam - 1;
        }

        if (tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105) {
            if (tam <= 4) {
                strCampo.value = vr;
            }
            if ((tam > 4) && (tam <= 7)) {
                strCampo.value = vr.substr(0, tam - 2) + '/' + vr.substr(tam - 2, tam);
            }
            if ((tam > 7) && (tam <= 10)) {
                strCampo.value = vr.substr(0, tam - 7) + '/' + vr.substr(tam - 7, 2) + '/' + vr.substr(tam - 5, tam);
            }
        }
    }
    </script>

    <script>
    function FormataCPF(Formulario, Campo, TeclaPres) {
        var tecla = TeclaPres.keyCode;
        var strCampo;
        var vr;
        var tam;
        var TamanhoMaximo = 11;

        eval("strCampo = document." + Formulario + "." + Campo);

        vr = strCampo.value;
        vr = vr.replace("/", "");
        vr = vr.replace("/", "");
        vr = vr.replace("/", "");
        vr = vr.replace(",", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace(".", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        vr = vr.replace("-", "");
        tam = vr.length;

        if (tam < TamanhoMaximo && tecla != 8) {
            tam = vr.length + 1;
        }

        if (tecla == 8) {
            tam = tam - 1;
        }

        if (tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105) {
            if (tam <= 2) {
                strCampo.value = vr;
            }
            if ((tam > 2) && (tam <= 5)) {
                strCampo.value = vr.substr(0, tam - 2) + '-' + vr.substr(tam - 2, tam);
            }
            if ((tam > 5) && (tam <= 8)) {
                strCampo.value = vr.substr(0, tam - 5) + '.' + vr.substr(tam - 5, 3) + '-' + vr.substr(tam - 2, tam);
            }
            if ((tam > 8) && (tam <= 11)) {
                strCampo.value = vr.substr(0, tam - 8) + '.' + vr.substr(tam - 8, 3) + '.' + vr.substr(tam - 5, 3) +
                    '-' + vr.substr(tam - 2, tam);
            }
        }
    }
    </script>

    <script type="text/javascript" src="checkcons.js" charset="utf-8"></script>
</head>

<body background="../images/bg1.jpg" text="#FFFFFF" onLoad="putFocus(0,0)">

    <?php

    include "../cabecprs.php";

    // Autorizando o Login
    $Sis     = "S7";
    $Rot     = "S7R2";
    $lg_user = $_REQUEST['c_s'];
      $user  = substr($lg_user,0,8);
      $pss   = substr($lg_user,8,40);
    $ABase   = date('Y');

    include "us_sist.php";
    
    if ($ch == 'no')
        {
	        include "us_cad.php";
        }

    if ($ch == 'ok-enc' or $ch == 'ok-cai' or $ch == 'ok')
    { ?>
    <font color='aqua' size='6'><b><u><i>
                    <center>CADASTRAMENTO <font color='#FFFFFF'>- <font color='gold'>CONSULTA</center>
                </i></u></b></font><br>
    <center>
        <font size='5'><b><i>Marque uma das Opções abaixo e selecione um dos Campos:</i></b></font><br><?php

		  // Exibindo Formulário ?>
        <form name="cadcons" method="post" action="consultatop_carne.php?c_s=<?php echo $lg_user; ?>"
            OnSubmit="JavaScript:return checkcli()">
            <font size="5" color='gold'><b><i>Fotografado em<br>
                        <font size="4" color='aqua'><?php echo $ABase; ?>:
                    </i></b></font>
            <input type='radio' name='rdnovo' class='campos' value='s'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <font size="4" color='lime'><b><i>Todos:</i></b></font>
            <input type='radio' name='rdnovo' class='campos' value='n'>

            <table align="center" border="10" cellpadding="6" cellspacing="0">
                <tr>
                    <td align='right'>
                        <font size="4" color='gold'><b><i>Código do Modelo: </i></b></font>
                        <input type='text' name='txtcodcli' maxlenght='4' size='25' class='campos'
                            OnKeyUp='validate(this)'>
                    </td>
                    <td align='right'>
                        <font size="4" color='gold'><b><i>CPF: </i></b></font>
                        <input type='text' name='txtcpf' maxlenght='14' size='25' class='campos'
                            onKeyUp="validCPF(this); FormataCPF('cadcons', 'txtcpf', event)">
                    </td>
                </tr>

                <tr>
                    <td align='right'>
                        <font size="4" color='gold'><b><i>Nome do Modelo: </i></b></font>
                        <input type='text' name='txtmod' size='25' maxlength='50' class='campos'
                            onkeypress="fPassaAlfaNumerico('an')"
                            onkeyup='this.value=this.value.toUpperCase(); validnome(this)'>
                    </td>
                    <td align='right'>
                        <font size="4" color='gold'><b><i>Nome do Responsável: </i></b></font>
                        <input type='text' name='txtresp' size='25' maxlength='50' class='campos'
                            onkeypress="fPassaAlfaNumerico('an')"
                            onkeyup='this.value=this.value.toUpperCase(); validnome(this)'>
                    </td>
                </tr>

                <tr>
                    <td align='right'>
                        <font size="4" color='gold'><b><i>Fotografados em: </i></b></font>
                        <input type='text' name='dtfotog' maxlenght='10' size='25' class='campos'
                            OnKeyUp="validata(this); FormataData('cadcons', 'dtfotog', event)">
                    </td>
                    <td align='right'>
                        <font size="4" color='gold'><b><i>Vendedora: </i></b></font>
                        <input type='text' name='txtvend' maxlenght='9' size='25' class='campos'
                            OnKeyUp='validate(this)'>
                    </td>
                </tr>
            </table><br>

            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td>
                        <center><a href='servrec.php?c_s=<?php echo $lg_user; ?>'><img src='./images/voltar.gif'
                                    border='0'></a></center>
                    </td>
                    <td align="center">
                        <input type="hidden" name="txtuser" value="<?php echo $lg_user; ?>">
                        <input type="submit" value="CONSULTAR">&nbsp;&nbsp;
                        <input type="reset" value="LIMPAR">
                    </td>
                    <td align="right">
                        <center><a href='servrec.php?c_s=<?php echo $lg_user; ?>'><img src='./images/voltar.gif'
                                    border='0'></a></center>
                    </td>
                </tr>
        </form>
        </table><br><?php
		 
	   
	} else { ?>
        <br><br><br><br>
        <font size='5'><b>
                <center>Acesso <font color='gold'>
                        <blink><u>não Autorizado</u></blink>
                        <font color='#FFFFFF'>!!!</center>
            </b></font><br><br><br><br><br>

        <center><a href="servrec.php?c_s=<?php echo $lg_user; ?>"><img src="./images/voltar.gif"></a></center><br><?php
	       }

      //$SisRot = "Off-2.4";
      include "../rodape.php"; ?>

</body>

</html>